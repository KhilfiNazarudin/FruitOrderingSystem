﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FOS_L1_201945D.Models.ViewModels
{
    public class OrderDetailsVM
    {
        public string Address { get; set; }

        public string ContactNumber { get; set; }

        public DateTime Date { get; set; }

        public OrderVM OrderVM { get; set; }

        public string UserName { get; set; }
        
    }
}
