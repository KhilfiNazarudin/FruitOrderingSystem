﻿using FOS_L1_201945D.Models;
using FOS_L1_201945D.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace FOS_L1_201945D.Controllers
{
    public class OrdersController : Controller
    {
        FruitsOrderDBContext FODBC;

        public OrdersController(FruitsOrderDBContext context)
        {
            FODBC = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Title = "Fruits Page";
            ICollection<Fruit> fruitlist = FODBC.Fruit
                                        //
                                        .Include(Fruit => Fruit.FruitCategory)
                                        .ToList();
            return View(fruitlist);
        }

        [HttpGet]
        public IActionResult Ordering()
        {
            OrderDetailsVM ODVM = new OrderDetailsVM();
            ODVM.OrderVM = new OrderVM();
            ODVM.OrderVM.Fruits = FODBC.Fruit.Include(b => b.FruitCategory).ToList();

            return View(ODVM);
        }

        [HttpPost]
        public IActionResult Ordering(OrderDetailsVM ODVM)
        {
            ODVM.OrderVM.Fruits = FODBC.Fruit.Include(b => b.FruitCategory).ToList();

            decimal tp = 0;
            Debug.WriteLine("PRE FOREACH LOOP");
            int var = 0;

            foreach (var x in ODVM.OrderVM.selected) //EMPTY
            {
                foreach(var z in ODVM.OrderVM.Fruits)
                {
                    if (x.Id == z.Id)
                    {
                        tp = tp + (z.Price * ODVM.OrderVM.quantity[var]);
                        var++;
                    }
                    
                }

            }

            Debug.WriteLine("AFT FOREACH LOOP");


            Order order = new Order
            {
                Address = ODVM.Address,
                ContactNumber = ODVM.ContactNumber,
                Date = ODVM.Date,
                UserName = ODVM.UserName,
                TotalPrice = tp
            };

            OrderItem orderitem = new OrderItem();

            try
            {
                if (ModelState.IsValid)
                {
                    FODBC.Order.Add(order);
                    FODBC.SaveChanges();

                    // if the bood is edited successfully, we call the Index action method
                    return RedirectToAction("Index");
                }
                else
                {
                    Debug.WriteLine("My debug string here");
                }
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Unable to add the book record." +
                    "Please try again, and if the problem persists," +
                    "Please see your system administrator");
            }
            

            return View(ODVM);

   
        }
    }
}
